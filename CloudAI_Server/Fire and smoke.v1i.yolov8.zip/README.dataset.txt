# Fire and smoke > 2024-11-23 9:50pm
https://universe.roboflow.com/khalid-zpnvl/fire-and-smoke-k8f3q

Provided by a Roboflow user
License: CC BY 4.0

